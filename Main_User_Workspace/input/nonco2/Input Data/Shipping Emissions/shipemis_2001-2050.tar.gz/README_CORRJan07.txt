==================
README_CORRFeb07
==================

Eyring, V., H. W. K�hler, A. Lauer, and B. Lemper (2005), Emissions from international shipping: 2. Impact of future technologies on scenarios until 2050, J. Geophys. Res., 110, D17306, doi:10.1029/2004JD005620.

There are some errors in Table 4 of the JGR paper 2 which are corrected below and in the attached emission files:

DS1-TS4:
========
The 23.4 Tg(NO2) and the 2.2 Tg for PM in the table of the paper in 2050 are 
wrong. The correct values are 28.6 (NOx) and 2.9 Tg for PM for DS1-TS4 in 2050.


DS1-TS3:
========
The 23.4 Tg(NO2) in 2050 in the table of the paper is wrong. The correct value is 21.5 Tg(NOx) in 2050. 


DS2-TS4:
========
The 2020 values in the paper are wrong for SOx, HC, PM, and CO. 
They should be 14.0, 4.6, 2.2, 1.8, just as in DS2-TS3 in 2020. It happened 
during copy editing and we missed to correct that in the galley proof, 
which is very unfortunate.



